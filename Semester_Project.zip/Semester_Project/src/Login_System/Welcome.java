package Login_System;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Store.*;

import javax.swing.JLabel;
import java.awt.Font;
import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Cursor;

public class Welcome extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Welcome dialog = new Welcome();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			//dialog.pack();
			dialog.setLocationRelativeTo(null);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Welcome() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		contentPanel.setBackground(Color.DARK_GRAY);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		setUndecorated(true);
		contentPanel.setLayout(null);
		{
			lblNewLabel = new JLabel("Welcome !");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setForeground(Color.GREEN);
			lblNewLabel.setBounds(79, 82, 279, 116);
			lblNewLabel.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 15));
			contentPanel.add(lblNewLabel);
		}
		
		JButton btnNewButton = new JButton("Store\r\n\r\n");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Mainpage a=new Mainpage();
				 //pack();
                 
                 a.frame.setLocationRelativeTo(null);
				a.frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(182, 209, 89, 23);
		contentPanel.add(btnNewButton);
		
		JButton btnContactUs = new JButton("Contact Us!");
		btnContactUs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contact a=new contact();
                a.setLocationRelativeTo(null);
				a.setVisible(true);
			}
		});
		btnContactUs.setBackground(SystemColor.activeCaption);
		btnContactUs.setBounds(326, 266, 114, 23);
		contentPanel.add(btnContactUs);
		
		JButton btnX = new JButton("X");
		btnX.setBackground(Color.GRAY);
		btnX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		btnX.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnX.setBounds(390, 11, 50, 30);
		contentPanel.add(btnX);
	}

}
