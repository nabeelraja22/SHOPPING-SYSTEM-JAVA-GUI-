package Store;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class Women_Fashion extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static int Total;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Women_Fashion frame = new Women_Fashion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Women_Fashion() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Colorfull Hairpins");
		lblNewLabel.setBounds(10, 60, 94, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblDimensionalWheatBrooch = new JLabel("Wheat Brooch");
		lblDimensionalWheatBrooch.setBounds(10, 103, 81, 14);
		contentPane.add(lblDimensionalWheatBrooch);
		
		JLabel lblHandBag = new JLabel("Hand bag");
		lblHandBag.setBounds(10, 159, 81, 14);
		contentPane.add(lblHandBag);
		
		final JRadioButton rb1 = new JRadioButton("");
		rb1.setBounds(333, 60, 21, 23);
		contentPane.add(rb1);
		
		final JRadioButton rb2 = new JRadioButton("");
		rb2.setBounds(333, 103, 21, 23);
		contentPane.add(rb2);
		
		final JRadioButton rb3 = new JRadioButton("");
		rb3.setBounds(333, 150, 21, 23);
		contentPane.add(rb3);
		
		textField = new JTextField();
		textField.setBounds(186, 57, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(186, 100, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(186, 156, 86, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Women Fashion");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(137, 11, 157, 23);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Add to cart");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int t=0;
				int to=0;
				int tot=0;
				int total;
				try {
					FileWriter writer=new FileWriter("E:\\cart.txt",true);
					if (rb1.isSelected()) {
						writer.write("\n");
						writer.write("Product: "+"Colorful Hairpins");
						writer.write("\n");
						writer.write("Price: "+"250");
						writer.write("\n");
						String p=textField.getText();
				    	int inum = Integer.parseInt(p);
				    	t=250*inum;
				    	writer.write("Quantity: "+inum);
				    	writer.write("\n");
				    	writer.write("-----------------------");
						writer.write("\n");
						
					}
					if (rb2.isSelected()) {
						writer.write("\n");
						writer.write("Product: "+"Wheat Brooch");
						writer.write("\n");
						writer.write("Price: "+"500");
						writer.write("\n");
						String p=textField.getText();
				    	int inum = Integer.parseInt(p);
				    	to=500*inum;
				    	writer.write("Quantity: "+inum);
				    	writer.write("\n");
				    	writer.write("-----------------------");
						writer.write("\n");
						
					}
					if (rb3.isSelected()) {
						writer.write("\n");
						writer.write("Product: "+"Hand Bag");
						writer.write("\n");
						writer.write("Price: "+"1500");
						writer.write("\n");
						String p=textField.getText();
				    	int inum = Integer.parseInt(p);
				    	tot=1500*inum;
				    	writer.write("Quantity: "+inum);
				    	writer.write("\n");
				    	writer.write("-----------------------");
						writer.write("\n");
						
					}
					 
					 writer.write("\n");
					 writer.write("-----------------------");
					 writer.close();
					 total=t+to+tot;
					 Total=total;
					JOptionPane.showMessageDialog(null,"Added to cart!");
				}
				catch(IOException e1){
					
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(141, 209, 131, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBounds(350, 227, 74, 23);
		contentPane.add(btnNewButton_1);
	}
}
