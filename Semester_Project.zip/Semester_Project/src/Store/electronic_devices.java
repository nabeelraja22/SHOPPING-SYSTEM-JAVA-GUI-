package Store;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.ComboBoxUI;

import Login_System.Register;

import javax.swing.JScrollBar;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.AbstractListModel;
import java.awt.SystemColor;

public class electronic_devices extends JFrame {
	File cart = new File("E:\\");
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static int Total;
		
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					electronic_devices frame = new electronic_devices();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public electronic_devices() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 602, 324);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.inactiveCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Electronic Devices");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel.setBounds(151, 11, 226, 30);
		contentPane.add(lblNewLabel);
		
		final JRadioButton rb1 = new JRadioButton("");
		rb1.setBounds(453, 65, 37, 23);
		contentPane.add(rb1);
		
		final JRadioButton rb2 = new JRadioButton("");
		rb2.setBounds(453, 108, 37, 23);
		contentPane.add(rb2);
		
		final JRadioButton rb3 = new JRadioButton("");
		rb3.setBounds(453, 166, 37, 23);
		contentPane.add(rb3);
		
		JButton btnNewButton = new JButton("Add to Cart");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s="";
				int total=0;
				int t=0;
				int to=0;
				int tot=0;
			    try {
					FileWriter writer=new FileWriter("E:\\cart.txt");
					 if (rb1.isSelected()) {
						 writer.write("\n");
					    	writer.write("Product: "+"3310");
					    	writer.write("\n");
					    	writer.write("Price: "+"2500");
					    	String p=textField.getText();
					    	int inum = Integer.parseInt(p);
					    	writer.write("\n");
					    	writer.write("Quantity: "+inum);
					    	t=2500*inum;
					    	writer.write("\n");
					    	 writer.write("-----------------------");
							 writer.write("\n");
					    	
					    	//dispose();
					    }
					if (rb2.isSelected()) {
						writer.write("\n");
				    	writer.write("Product: "+"Galaxy s9");
				    	writer.write("\n");
				    	writer.write("Price: "+"25,000");
				    	String p=textField_1.getText();
				    	int inum = Integer.parseInt(p);
				    	writer.write("\n");
				    	writer.write("Quantity: "+inum);
				    	to=25000*inum;
				    	writer.write("\n");
				    	 writer.write("-----------------------");
						 writer.write("\n");
				    	
				    }
				   if (rb3.isSelected()) {
					   writer.write("\n");
				    	writer.write("Product: "+"Iphone X");
				    	writer.write("\n");
				    	writer.write("Price: "+"125,000");
				    	String p=textField_2.getText();
				    	int inum = Integer.parseInt(p);
				    	writer.write("\n");
				    	writer.write("Quantity: "+inum);
				    	tot=125000*inum;
				    	writer.write("\n");
				    	 writer.write("-----------------------");
						 writer.write("\n");
				    	
				    }
				     total=t+to+tot;				   	 
					 writer.write("\n");
					 writer.write("-----------------------");
					 writer.close();
					 Total=	total;
					 JOptionPane.showMessageDialog(null,"Added to cart!");
					 
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			   
			   
			}
		}
			
		);
		btnNewButton.setBounds(220, 239, 105, 23);
		contentPane.add(btnNewButton);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("3310");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(71, 74, 57, 14);
		contentPane.add(lblNewLabel_1);
		
		
		
		JLabel lblNewLabel_2 = new JLabel("Galaxy s9");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(71, 108, 85, 23);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Iphone X");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3.setBounds(71, 166, 85, 23);
		contentPane.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		textField.setBounds(327, 68, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(327, 111, 86, 20);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(327, 169, 86, 20);
		contentPane.add(textField_2);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(453, 251, 89, 23);
		contentPane.add(btnNewButton_1);
	}
}
