package Store;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import Login_System.contact;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JSeparator;
import javax.swing.JPanel;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Logger;
public class Mainpage {

	public JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mainpage window = new Mainpage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @return 
	 */
	public Mainpage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.inactiveCaption);
		frame.setBounds(100, 100, 834, 407);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setUndecorated(true);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("X");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnNewButton.setForeground(new Color(255, 127, 80));
		btnNewButton.setBounds(770, 22, 54, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Electronic Devices");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				electronic_devices a=new electronic_devices();
				
				a.setLocationRelativeTo(null);
				a.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(70, 139, 140, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Electronic Accessories");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Under Maintenance!Please try again later.");
			}
		});
		btnNewButton_1_1.setBounds(63, 295, 192, 23);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JButton btnNewButton_1_3 = new JButton("Health & Beauty");
		btnNewButton_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Under Maintenance!Please try again later.");
			}
		});
		btnNewButton_1_3.setBounds(70, 191, 140, 23);
		frame.getContentPane().add(btnNewButton_1_3);
		
		JButton btnNewButton_1_4 = new JButton("Babies & Toys");
		btnNewButton_1_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Under Maintenance!Please try again later.");
			}
		});
		btnNewButton_1_4.setBounds(70, 243, 140, 23);
		frame.getContentPane().add(btnNewButton_1_4);
		
		JButton btnNewButton_1_6 = new JButton("Home & Lifestyle");
		btnNewButton_1_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Under Maintenance!Please try again later.");
			}
		});
		btnNewButton_1_6.setBounds(324, 243, 156, 23);
		frame.getContentPane().add(btnNewButton_1_6);
		
		JButton btnNewButton_1_7 = new JButton("Women's Fashion");
		btnNewButton_1_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Women_Fashion w=new Women_Fashion();
				w.setLocationRelativeTo(null);
				w.setVisible(true);
				
			}
		});
		btnNewButton_1_7.setBounds(324, 139, 156, 23);
		frame.getContentPane().add(btnNewButton_1_7);
		
		JButton btnNewButton_1_8 = new JButton("Men's Fashion");
		btnNewButton_1_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Under Maintenance!Please try again later.");
			}
		});
		btnNewButton_1_8.setBounds(324, 191, 156, 23);
		frame.getContentPane().add(btnNewButton_1_8);
		
		JButton btnNewButton_1_10 = new JButton("Sports & Outdoor");
		btnNewButton_1_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Under Maintenance!Please try again later.");
			}
		});
		btnNewButton_1_10.setBounds(324, 295, 156, 23);
		frame.getContentPane().add(btnNewButton_1_10);
		
		JButton btnNewButton_1_11 = new JButton("Automotive & Motorbike");
		btnNewButton_1_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Under Maintenance!Please try again later.");
			}
		});
		btnNewButton_1_11.setBounds(174, 346, 176, 23);
		frame.getContentPane().add(btnNewButton_1_11);
		
		JLabel lblNewLabel = new JLabel("Welcome !");
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(281, 11, 224, 34);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Please select any of the following");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Segoe Script", Font.BOLD, 22));
		lblNewLabel_1.setBounds(69, 56, 668, 35);
		frame.getContentPane().add(lblNewLabel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(216, 191, 216));
		panel.setBounds(521, 94, 313, 313);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton_1_13 = new JButton("Contact Us!");
		btnNewButton_1_13.setFont(new Font("Segoe Script", Font.BOLD, 16));
		btnNewButton_1_13.setBounds(70, 225, 176, 23);
		panel.add(btnNewButton_1_13);
		btnNewButton_1_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				contact a=new contact();
				a.setLocationRelativeTo(null);
				a.setVisible(true);
			}
		});
		
		JButton btnNewButton_2 = new JButton("Cart");
		btnNewButton_2.setBounds(70, 116, 176, 25);
		panel.add(btnNewButton_2);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s="";
				int Total=Women_Fashion.Total+electronic_devices.Total;
				 try {
					 FileWriter writer=new FileWriter("E:\\cart.txt",true);
					 writer.write("\n");
					 writer.write("Total: "+Total);
					 writer.write("\n");
					 writer.write("-----------------------");
					 writer.close();
					   s=new String(Files.readAllBytes(Paths.get("E:\\cart.txt")));
					   
				   }catch(IOException e4){
					     e4.printStackTrace();
				    
				    }
				   JOptionPane.showMessageDialog(null,s);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		
		
		
		JButton btnNewButton_1_11_1_1 = new JButton("Track Your Order!");
		btnNewButton_1_11_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String resp = "Please enter your Tracking Number: ";
			    JOptionPane.showInputDialog(null, resp);
			    JOptionPane.showMessageDialog(null, "Your Product is on it's way! Stay Tuned!");
			}
		});
		btnNewButton_1_11_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1_11_1_1.setBounds(70, 174, 176, 23);
		panel.add(btnNewButton_1_11_1_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Options");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Segoe Script", Font.BOLD, 24));
		lblNewLabel_1_1.setBounds(35, 11, 231, 35);
		panel.add(lblNewLabel_1_1);
		
		JButton btnNewButton_3 = new JButton("Clear Cart");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File f = new File("E:\\cart.txt");
				if(f.exists()){
					f.delete();
					
					try {
						f.createNewFile();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Cart Cleared!");
				}
				else {
					JOptionPane.showMessageDialog(null, "Error Occured!");
				}
				
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_3.setBounds(10, 259, 114, 23);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Checkout");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null,"Order Placed!");
				
				try {
					
					FileWriter writer=new FileWriter("E:\\trackingnumbers.txt",true);
					Random rand = new Random();
					int tr= rand.nextInt(99999);
					JOptionPane.showMessageDialog(null,"Your tracking number is: "+tr);
					writer.write("\n");
					writer.write("Your tracking number is: "+tr);
					writer.write("\n");
					writer.write("-----------");
					writer.close();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_4.setBounds(177, 259, 89, 23);
		panel.add(btnNewButton_4);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(0, 91, 834, 23);
		frame.getContentPane().add(separator);
		separator.setBackground(SystemColor.desktop);
	}
}


